package com.example.adam_2.mpdcw;

/**
 * Created by Adam_2 on 11/03/2018.
 */

// Adam Canavan
// S1428438

public class ParseData {

    private String title;
    private String description;
    private String link;
    private String geo;
    private String author;
    private String comment;
    private String date;

    public ParseData()
    {
        title = "";
        description = "";
        link = "";
        geo = "";
        author = "";
        comment = "";
        date = "";
    }

    public ParseData(String atitle, String adescription, String alink, String ageo, String aauthor, String acomment, String adate)
    {

        title = atitle;
        description = adescription;
        link = alink;
        geo = ageo;
        author = aauthor;
        comment = acomment;
        date = adate;
    }


    public String getTitle()
    {
        return title;
    }

    public void setTitle(String atitle)
    {
        title = atitle;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String adescription)
    {
        description = adescription;
    }

    public String getLink()
    {
        return link;
    }

    public void setLink(String alink)
    {
        link = alink;
    }

    public String getGeo()
    {
        return geo;
    }

    public void setGeo(String ageo)
    {
        geo = ageo;
    }

    public String getAuthor()
    {
        return author;
    }

    public void setAuthor(String aauthor)
    {
        author = aauthor;
    }

    public String getComment()
    {
        return comment;
    }

    public void setComment(String acomment)
    {
        comment = acomment;
    }

    public String getDate()
    {
        return date;
    }

    public void setDate(String adate)
    {
        date = adate;
    }

    public String toString()
    {
        String xmlData;

        xmlData = "\n" + title + "\n" + description + "\n" + link + "\n" + geo + "" + author + "" + comment + "" + date + "\n";

        return xmlData;
    }
}
