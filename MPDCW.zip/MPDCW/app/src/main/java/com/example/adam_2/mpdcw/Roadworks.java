package com.example.adam_2.mpdcw;

//
//
// Starter code for the Mobile Platform Development Assignment
// Seesion 2017/2018
// Adam canavan
// S1428438


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.LinkedList;

import static android.R.attr.editable;


public class Roadworks extends AppCompatActivity implements View.OnClickListener {

    private String url3 = "https://trafficscotland.org/rss/feeds/plannedroadworks.aspx";
    private TextView urlInput;
    private Button Button;
    private String result = "";
    private ScrollView scrollView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.roadworks);
        urlInput = (TextView) findViewById(R.id.urlInput);
        Button = (Button) findViewById(R.id.roadButton);
        Button.setOnClickListener(this);
        scrollView = (ScrollView) findViewById(R.id.scroll);


    }


    // End of onCreate

    private LinkedList<ParseData> parseData(String dataToParse) {
        LinkedList <ParseData> alist = new LinkedList<ParseData>();
        ParseData pdata = new ParseData();

        try {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser xpp = factory.newPullParser();

            xpp.setInput(new StringReader(dataToParse));
            int eventType = xpp.getEventType();

            while (eventType != XmlPullParser.END_DOCUMENT){
                if(eventType == XmlPullParser.START_DOCUMENT) {
                    System.out.println("Start of Roadworks Feed");
                }
                if (eventType == XmlPullParser.START_TAG) {

                    //Checks tags in XML
                    if (xpp.getName().equalsIgnoreCase("channel")) {
                        alist = new LinkedList<ParseData>();
                    }

                    else if (xpp.getName().equalsIgnoreCase("item")) {

                        pdata = new ParseData();
                    }

                    else if (xpp.getName().equalsIgnoreCase("title")) {
                        String temp = xpp.nextText();
                        Log.e("MyTag", "Title: " + temp);
                        pdata.setTitle(temp);
                    }

                    else if (xpp.getName().equalsIgnoreCase("description")) {
                        String temp = xpp.nextText();
                        Log.e("MyTag", "Description: " + temp);
                        pdata.setDescription(temp);
                    }

                    else if (xpp.getName().equalsIgnoreCase("link")) {
                        String temp = xpp.nextText();
                        Log.e("MyTag", "Link: " + temp);
                        pdata.setLink(temp);
                    }

                    else if (xpp.getName().equalsIgnoreCase("geoPoint")) {
                        String temp = xpp.nextText();
                        Log.e("MyTag", "Geo Point: " + temp);
                        pdata.setGeo(temp);
                    }

                    else if (xpp.getName().equalsIgnoreCase("author")) {
                        String temp = xpp.nextText();
                        Log.e("MyTag", "Author: " + temp);
                        pdata.setAuthor(temp);
                    }

                    else if (xpp.getName().equalsIgnoreCase("comment")) {
                        String temp = xpp.nextText();
                        Log.e("MyTag", "Comment: " + temp);
                        pdata.setComment(temp);
                    }

                    else if (xpp.getName().equalsIgnoreCase("pubDate")) {
                        String temp = xpp.nextText();
                        Log.e("MyTag", "Date: " + temp);
                        pdata.setDate(temp);
                    }
                }

                else if(eventType == XmlPullParser.END_TAG) {
                    if (xpp.getName().equalsIgnoreCase("item"))
                    {
                        Log.e("MyTag", "" + pdata.toString());
                        System.out.print("Details listed about the Planned Roadworks: " + pdata.toString());
                        alist.add(pdata);
                    }
                    // shows 0 if no items in channel
                    else if (xpp.getName().equalsIgnoreCase("channel")) {
                        int size;
                        size = alist.size();
                        Log.e("MyTag", "There are " + size + " Planned Roadworks");
                    }
                }
                //Get the next event
                eventType = xpp.next();
            } // End of while

            System.out.println("End Document");

            return alist;
        }
        catch (XmlPullParserException ae1)
        {
            Log.e("MyTag", "Parsing error" + ae1.toString());
        }
        catch (IOException ae1)
        {
            Log.e("MyTag", "IO error during parsing");
        }

        Log.e("MyTag", "End document");

        return alist;
    }

    public void onClick(View view) {
        startProgress(view);
    }

//    editText.addTextChangedListener(new TextWatcher() {
//        @Override
//        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//        }
//
//        @Override
//        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//            if (charSequence.length() == 0) {
//                String fullText = urlInput.getText().toString();
//                fullText = fullText.replace("<font color='red'>", "");
//                fullText = fullText.replace("</font>", "");
//                urlInput.setText(fullText);
//            }
//        }
//
//        @Override
//        public void afterTextChanged(Editable editable) {
//
//        }
//    });



    public void startProgress(View view) {
        // Run network access on a separate thread;
       if (view.getId() == R.id.roadButton)
        {
            new Thread(new roadworks(url3)).start();
        }
    }

    //
    // Need separate thread to access the internet resource over network
    // Other neater solutions should be adopted in later iterations.
    class Task implements Runnable {
        private String url;

        public Task(String aurl) {
            url = aurl;
        }



        @Override
        public void run() {

            final URL aurl;
            URLConnection yc;
            BufferedReader in = null;
            String inputLine = "";


            Log.e("MyTag", "in run");

            try {
                Log.e("MyTag", "in try");
                aurl = new URL(url);
                yc = aurl.openConnection();
                in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
                //
                // Throw away the first 2 header lines before parsing
                //
                //
                //
                if(!result.equals(""))
                {
                    result = "";
                }
                while ((inputLine = in.readLine()) != null) {
                    result = result + inputLine;

                    //testing that we have the right xml url
                    //Log.e("MyTag InputLine", inputLine);
                }
                in.close();
            } catch (IOException ae) {
                Log.e("MyTag", "ioexception");
            }

            // Now that you have the xml data you can parse it
            final LinkedList<ParseData> alist;
            final ParseData pdata = new ParseData();

            alist = parseData(result);

            if (alist != null)
            {
                Log.e("MyTag", "List is not null");
                for (Object o : alist)

                {

                }
            }
            else
            {

                Log.e("MyTag", "List is null");
            }

            // Now update the TextView to display raw XML data
            // Probably not the best way to update TextView
            // but we are just getting started !

            Roadworks.this.runOnUiThread(new Runnable() {
                public void run() {
                    Log.d("UI thread", "I am the UI thread");

                    if (alist.size() == 0)
                    {
                        urlInput.setText("No Current Planned Roadworks");
                    }
                    else
                        {
                            urlInput.setText(alist.toString().replace("[", "").replace("]", "").replace(" ,", ""));
                        }
                }
            });
        }
    }

    class roadworks implements Runnable {
        private String url3;

        public roadworks(String aurl) {
            url3 = aurl;
        }
        @Override
        public void run() {

            final URL aurl;
            URLConnection yc;
            BufferedReader in = null;
            String inputLine = "";


            Log.e("MyTag", "in run");

            try {
                Log.e("MyTag", "in try");
                aurl = new URL(url3);
                yc = aurl.openConnection();
                in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
                //
                // Throw away the first 2 header lines before parsing
                //
                //
                //
                if(!result.equals(""))
                {
                    result = "";
                }
                while ((inputLine = in.readLine()) != null) {
                    result = result + inputLine;

                    //testing that we have the right xml url
                    //Log.e("MyTag InputLine", inputLine);
                }
                in.close();
            } catch (IOException ae) {
                Log.e("MyTag", "ioexception");
            }

            // Now that you have the xml data you can parse it
            final LinkedList<ParseData> alist;
            final ParseData pdata = new ParseData();

            alist = parseData(result);

            if (alist != null)
            {
                Log.e("MyTag", "List is not null");
                for (Object o : alist)

                {

                }
            }
            else
            {

                Log.e("MyTag", "List is null");
            }

            // Now update the TextView to display raw XML data
            // Probably not the best way to update TextView
            // but we are just getting started !

            Roadworks.this.runOnUiThread(new Runnable() {
                public void run() {
                    Log.d("UI thread", "I am the UI thread");

                    urlInput.setText(alist.toString().replace("[", "").replace("]", "").replace(",", "").replace("<br />", ""));

                }
            });
        }
    }


}