package com.example.adam_2.mpdcw;

/**
 * Created by acanav200 on 3/18/2018.
 */

// Adam Canavan S1428438

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;


public class FirstPage extends AppCompatActivity {

    private Button incidents;
    private Button roadworks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.first_page);
        incidents = (Button) findViewById(R.id.incidents);
        roadworks = (Button) findViewById(R.id.roadworks);


        incidents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity();
            }
        });


        roadworks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Roadworks();
            }
        });

        ImageView img = (ImageView)findViewById(R.id.imageView2);
        img.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://trafficscotland.org"));
                startActivity(intent);
            }
        });
    }


    public void MainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void Roadworks() {
        Intent intent = new Intent(this, Roadworks.class);
        startActivity(intent);
    }
}



