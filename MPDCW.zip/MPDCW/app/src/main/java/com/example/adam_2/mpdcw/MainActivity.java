package com.example.adam_2.mpdcw;

//
//
// Starter code for the Mobile Platform Development Assignment
// Seesion 2017/2018
// Adam canavan
// S1428438


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.LinkedList;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private String url1 = "https://trafficscotland.org/rss/feeds/currentincidents.aspx";
    private TextView urlInput;
    private Button incidentButton;
    private Button roadButton;
    private String result = "";
//    LinearLayout PBar;
//    private EditText searchIncidents;
//    private LinkedList<ParseData> incidentFeed = new LinkedList<>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        urlInput = (TextView) findViewById(R.id.urlInput);
        incidentButton = (Button) findViewById(R.id.incidentButton);
        incidentButton.setOnClickListener(this);
        //searchIncidents = (EditText)findViewById(R.id.searchIncidents);

// PBar = (LinearLayout) findViewById(R.id.progressBar);
//        editText = (EditText) findViewById(R.id.editText);

    }


     // End of onCreate

    private LinkedList<ParseData> parseData(String dataToParse) {
        LinkedList <ParseData> alist = new LinkedList<ParseData>();
        ParseData pdata = new ParseData();


        try {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser xpp = factory.newPullParser();

            xpp.setInput(new StringReader(dataToParse));
            int eventType = xpp.getEventType();

            while (eventType != XmlPullParser.END_DOCUMENT){
                if(eventType == XmlPullParser.START_DOCUMENT) {
                    System.out.println("Start of Incident Feed");
                }
                if (eventType == XmlPullParser.START_TAG) {


                    if (xpp.getName().equalsIgnoreCase("channel")) {
                        alist = new LinkedList<ParseData>();
                    }
                    //Checks tags in XML
                    else if (xpp.getName().equalsIgnoreCase("item")) {

                        pdata = new ParseData();
                    }

                    else if (xpp.getName().equalsIgnoreCase("title")) {
                        String temp = xpp.nextText();
                        Log.e("MyTag", "Title: " + temp);
                        pdata.setTitle(temp);
                    }

                    else if (xpp.getName().equalsIgnoreCase("description")) {
                        String temp = xpp.nextText();
                        Log.e("MyTag", "Description: " + temp);
                        pdata.setDescription(temp);
                    }

                    else if (xpp.getName().equalsIgnoreCase("link")) {
                        String temp = xpp.nextText();
                        Log.e("MyTag", "Link: " + temp);
                        pdata.setLink(temp);
                    }

                    else if (xpp.getName().equalsIgnoreCase("geoPoint")) {
                        String temp = xpp.nextText();
                        Log.e("MyTag", "Geo Point: " + temp);
                        pdata.setGeo(temp);
                    }

                    else if (xpp.getName().equalsIgnoreCase("author")) {
                        String temp = xpp.nextText();
                        Log.e("MyTag", "Author: " + temp);
                        pdata.setAuthor(temp);
                    }

                    else if (xpp.getName().equalsIgnoreCase("comment")) {
                        String temp = xpp.nextText();
                        Log.e("MyTag", "Comment: " + temp);
                        pdata.setComment(temp);
                    }

                    else if (xpp.getName().equalsIgnoreCase("pubDate")) {
                        String temp = xpp.nextText();
                        Log.e("MyTag", "Date Published: " + temp);
                        pdata.setDate(temp);
                    }
                }

                else if(eventType == XmlPullParser.END_TAG) {
                    if (xpp.getName().equalsIgnoreCase("item"))
                    {
                        Log.e("MyTag", "" + pdata.toString());
                        System.out.print("Details about the Incident that have occurred: " + pdata.toString());
                        alist.add(pdata);
                    }

//                    if(pdata.getTitle().contains(searchIncident))
//                    {
//                        incidentFeed.add(pdata);
//                    }

                    // shows 0 if no items in channela
                    else if (xpp.getName().equalsIgnoreCase("channel")) {
                        int size;
                        size = alist.size();
                        Log.e("MyTag", "There are " + size + " Current Incidents");
                    }
                }
                //Gets the next event
                eventType = xpp.next();
            } // End of while

            System.out.println("End Document");

            return alist;
        }
        catch (XmlPullParserException ae1)
        {
            Log.e("MyTag", "Parsing error" + ae1.toString());
        }
        catch (IOException ae1)
        {
            Log.e("MyTag", "IO error during parsing");
        }

        Log.e("MyTag", "End document");

        return alist;
    }

    public void onClick(View view) {
        startProgress(view);

//        progressBar.setVisibility(View.VISIBLE);
//        setLoadingText(PBar, "Getting Data");
    }

    public void startProgress(View view) {
        // Run network access on a separate thread;
        if (view.getId() == R.id.incidentButton)
        {
            new Thread(new Task(url1)).start();
        }

    }

    //
    // Need separate thread to access the internet resource over network
    // Other neater solutions should be adopted in later iterations.
    class Task implements Runnable {
        private String url;

        public Task(String aurl) {
            url = aurl;
        }


        @Override
        public void run() {

            final URL aurl;
            URLConnection yc;
            BufferedReader in = null;
            String inputLine = "";


            Log.e("MyTag", "in run");

            try {
                Log.e("MyTag", "in try");
                aurl = new URL(url);
                yc = aurl.openConnection();
                in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
                //
                // Throw away the first 2 header lines before parsing
                //
                //
                //
                if(!result.equals(""))
                {
                    result = "";
                }
                while ((inputLine = in.readLine()) != null) {
                    result = result + inputLine;

                    //testing that we have the right xml url
                    //Log.e("MyTag InputLine", inputLine);
                }
                in.close();
            } catch (IOException ae) {
                Log.e("MyTag", "ioexception");
            }

            // Now that you have the xml data you can parse it
            final LinkedList<ParseData> alist;
            final ParseData pdata = new ParseData();

            alist = parseData(result);

            if (alist != null)
            {
                Log.e("MyTag", "List is not null");
                for (Object o : alist)

                {

                }
            }
            else
                {

                    Log.e("MyTag", "List is null");
            }

            // Now update the TextView to display raw XML data
            // Probably not the best way to update TextView
            // but we are just getting started !

            MainActivity.this.runOnUiThread(new Runnable() {
                public void run() {
                    Log.d("UI thread", "I am the UI thread");
                    // if there are no items then the appropriate output will be displayed to the user
                    if (alist.size() == 0)
                    {
                        urlInput.setText("No Current Incidents");
                    }
                    else
                    {
                        //replaces characters in the xml file with spaces. Better for design
                        urlInput.setText(alist.toString().replace("[", "").replace("]", "").replace(" ,", "").replace(",", ""));
                    }



                }
            });
        }
    }

//    public void setLoadingText(LinearLayout layout, String text)
//    {
//        int count = layout.getChildCount();
//        for(int  i = 0; i < count; i++)
//        {
//            if(layout.getChildAt(i) instanceof TextView)
//                ((TextView) layout.getChildAt(i)).setText(text);
//            if(layout.getChildAt(i) instanceof ProgressBar)
//                layout.getChildAt(i).setVisibility(View.GONE);
//        }
//    }


}